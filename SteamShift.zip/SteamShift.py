import os
import sys
# ================================================
# Helper to locate resources both in dev and in PyInstaller onefile
# ================================================
def resource_path(relative_path):
    """
    Get absolute path to resource, works for dev and for PyInstaller bundled exe.
    """
    if hasattr(sys, '_MEIPASS'):
        base = sys._MEIPASS
    else:
        base = os.path.abspath(os.path.dirname(__file__))
    return os.path.join(base, relative_path)

# ================================================
# Suppress unwanted stdout/stderr during imports
# ================================================
sys.stdout = open(os.devnull, 'w')
sys.stderr = open(os.devnull, 'w')
import pygame
sys.stdout = sys.__stdout__
sys.stderr = sys.__stderr__

import customtkinter as ctk
import json
import threading
import time
import tkinter as tk
from tkinter import messagebox
import shutil
import subprocess
import datetime
import winreg
import requests
import psutil
from io import BytesIO
from PIL import Image, ImageTk, ImageSequence
from bs4 import BeautifulSoup
import vdf
from tkinterdnd2 import DND_FILES, TkinterDnD
from functools import partial

from update_manager import check_and_update
if not check_and_update():
    sys.exit()

# --------------------------------------------------------------------------------------------------
# Configuration (all paths now via resource_path)
# --------------------------------------------------------------------------------------------------
SPLASH_ASCII   = resource_path("splash.txt")
SPLASH_WAV     = resource_path("splash.wav")
SETTINGS_PATH  = resource_path("settings.json")
WINDOW_CFG     = resource_path("window_config.json")
AVATAR_DIR     = os.path.join(os.environ.get('TEMP','.'), 'SteamSwitcher_Avatars')
TERMS_FILES    = {
    'ar': resource_path("terms_ar.txt"),
    'en': resource_path("terms_en.txt")
}

os.makedirs(AVATAR_DIR, exist_ok=True)

# --------------------------------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------------------------------
def load_settings():
    if os.path.exists(SETTINGS_PATH):
        try:
            return json.load(open(SETTINGS_PATH, encoding="utf-8"))
        except:
            pass
    default = {
        "first_run": True,
        "theme": "dark",
        "language": "ar",
        "background": "",
        "animated_background": True,
        "window": None
    }
    save_settings(default)
    return default

def save_settings(s):
    with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
        json.dump(s, f, indent=4)

def get_steam_path():
    try:
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                             r"SOFTWARE\\WOW6432Node\\Valve\\Steam")
        path, _ = winreg.QueryValueEx(key, "InstallPath")
        exe = os.path.join(path, "steam.exe")
        if os.path.exists(exe):
            return exe
    except:
        pass
    default = r"C:\Program Files (x86)\Steam\steam.exe"
    return default if os.path.exists(default) else None

def is_steam_running():
    for proc in psutil.process_iter(['name']):
        if proc.info['name'] and proc.info['name'].lower()=="steam.exe":
            return True
    return False

STEAM_PATH      = get_steam_path()
LOGINUSERS_PATH = os.path.join(os.path.dirname(STEAM_PATH), 'config', 'loginusers.vdf') if STEAM_PATH else None

# --------------------------------------------------------------------------------------------------
# ASCII Splash (horizontal reveal + sound)
# --------------------------------------------------------------------------------------------------
def show_ascii_splash(settings):
    if not settings.get("first_run", True):
        return False
    settings["first_run"] = False
    save_settings(settings)

    # init pygame for sound
    pygame.mixer.init()
    try:
        pygame.mixer.music.load(SPLASH_WAV)
    except:
        pass

    root = tk.Tk()
    root.overrideredirect(True)
    w, h = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry(f"{w}x{h}+0+0")
    root.configure(bg="#000000")

    # play sound
    try:
        pygame.mixer.music.play()
    except:
        pass

    lines = open(SPLASH_ASCII, encoding="utf-8").read().splitlines()
    rows, cols = len(lines), max(len(l) for l in lines)
    lines = [l.ljust(cols) for l in lines]
    display = [list(" " * cols) for _ in range(rows)]

    label = tk.Label(
        root,
        text="\n".join("".join(row) for row in display),
        font=("Consolas", 7),
        fg="#00FF00", bg="#000000",
        justify="left", anchor="nw"
    )
    label.place(x=250, y=50, width=w, height=h-100)

    idx_row = 0
    def step_row():
        nonlocal idx_row
        if idx_row >= rows:
            def close_and_launch():
                try:
                    pygame.mixer.music.stop()
                except:
                    pass
                root.destroy()
                SteamSwitcherApp().mainloop()
            root.after(2000, close_and_launch)
            return
        display[idx_row] = list(lines[idx_row])
        idx_row += 1
        label.configure(text="\n".join("".join(r) for r in display))
        root.after(30, step_row)

    root.after(100, step_row)
    root.mainloop()
    try:
        pygame.mixer.quit()
    except:
        pass
    return True

# --------------------------------------------------------------------------------------------------
# Main Application
# --------------------------------------------------------------------------------------------------
class SteamSwitcherApp(TkinterDnD.Tk):
    def __init__(self):
        super().__init__()

        # Load settings
        self.settings = load_settings()
        self.LANG     = self.settings.get("language","ar")
        ctk.set_appearance_mode(self.settings.get("theme","dark"))
        ctk.set_default_color_theme("dark-blue")

        # Restore window size & position or fullscreen
        if self.settings.get("window"):
            wcfg = self.settings["window"]
            self.geometry(f"{wcfg['width']}x{wcfg['height']}+{wcfg['x']}+{wcfg['y']}")
        else:
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
            self.state("zoomed")

        self.title("⚡ SteamShift")
        self.configure(bg="#000000")
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.bind("<Configure>", self._on_resize)
        self.bind("<B1-Motion>", lambda e: self.focus())

        # UI state
        self.bg_label      = None
        self.bg_frames     = None
        self.bg_index      = 0
        self.settings_menu = None
        self.terms_popup   = None

        # Build UI
        self._build_ui()
        self._load_background(self.winfo_width(), self.winfo_height())
        self.load_accounts()

        # Version label bottom-right
        try:
            version = open(resource_path("version.txt"), "r").read().strip()
        except:
            version = "v1.0"
        ver_lbl = ctk.CTkLabel(
            self,
            text=version,
            font=("Segoe UI", 12, "bold"),
            text_color="#FA0000"
        )
        ver_lbl.place(relx=1.0, rely=1.0, anchor="se", x=-10, y=-5)

        # Drag & drop
        self.drop_target_register(DND_FILES)
        self.dnd_bind("<<Drop>>", self._on_drop)

    def translate(self, ar, en):
        return ar if self.LANG=="ar" else en

    # ---------------- UI Construction ----------------
    def _build_ui(self):
        self.columnconfigure(0, weight=1)
        # Header
        self.header = ctk.CTkLabel(
            self, text=self.translate("🎮 SteamShift","🎮 SteamShift"),
            font=("Segoe UI",24,"bold"), text_color="#6F83A1"
        )
        self.header.grid(row=0, column=0, pady=(20,10))

        # Settings button
        self.settings_btn = ctk.CTkButton(
            self, text="⚙️", width=40,
            command=self.toggle_settings_menu
        )
        self.settings_btn.place(x=20,y=20)

        # Scrollable frame for accounts
        self.scroll_frame = ctk.CTkScrollableFrame(self, width=800, height=600)
        self.scroll_frame.grid(row=1, column=0, padx=20, pady=(10,10))

        # Refresh button
        self.refresh_btn = ctk.CTkButton(
            self,
            text="🔄 "+self.translate("تحديث القائمة","Refresh List"),
            fg_color="#3F4663", font=("Segoe UI",14,"bold"),
            command=self.load_accounts
        )
        self.refresh_btn.grid(row=2, column=0, pady=(5,20))

    # ---------------- Settings Menu ----------------
    def toggle_settings_menu(self):
        if self.settings_menu and self.settings_menu.winfo_exists():
            self.settings_menu.destroy()
            self.settings_menu = None
            return
        f = self.settings_menu = ctk.CTkFrame(self, width=240, fg_color="#322D42")
        f.place(x=20,y=60)
        ctk.CTkButton(f, text="🌐 "+self.translate("تغيير اللغة","Change Language"),
                      fg_color="#162A34", command=self._toggle_language).pack(fill="x", padx=10,pady=5)
        ctk.CTkButton(f, text=self.translate("🌓 المظهر","🌓 Theme"),
                      fg_color="#48708B", command=self._toggle_theme).pack(fill="x", padx=10,pady=5)
        ctk.CTkButton(f, text=self.translate("🧹 إزالة الخلفية","🧹 Clear Background"),
                      fg_color="#162A34", command=self._clear_background).pack(fill="x", padx=10,pady=5)

        social_frame = ctk.CTkFrame(f, fg_color="#282A36")
        social_frame.pack(padx=10, pady=10, fill="x")
        for key, ar, en, url in [
            ("twitter","تويتر","🐦 Twitter","https://twitter.com/your_twitter_handle"),
            ("website","موقع","🌐 Website","https://yourwebsite.com")
        ]:
            btn = ctk.CTkButton(
                social_frame, text=en if self.LANG=='en' else ar,
                fg_color="#44475a",
                command=partial(subprocess.Popen, ["start","",""+url], shell=True)
            )
            btn.pack(side="left", expand=True, padx=5, pady=5)

        ctk.CTkButton(f, text=self.translate("📜 الشروط","📜 Terms & Rights"),
                      fg_color="#805500", command=self._show_terms).pack(fill="x", padx=10,pady=(5,10))
        cf = ctk.CTkFrame(f, fg_color="#1f1f1f", corner_radius=8,
                         border_width=1, border_color="#555555")
        cf.pack(fill="x", padx=10,pady=(0,10))
        ctk.CTkLabel(cf, text=self.translate("حقوق © فهد القحطاني","© Fahd Alqahtani"),
                     font=("Segoe UI",14,"bold"), text_color="#FFFFFF").pack(pady=8)

    def _toggle_language(self):
        self.LANG = "en" if self.LANG=="ar" else "ar"
        self.settings["language"] = self.LANG; save_settings(self.settings)
        self.header.configure(text=self.translate("🎮 SteamShift","🎮 SteamShift"))
        self.refresh_btn.configure(text="🔄 "+self.translate("تحديث القائمة","Refresh List"))
        self.load_accounts()
        if self.settings_menu and self.settings_menu.winfo_exists():
            self.toggle_settings_menu(); self.toggle_settings_menu()

    def _toggle_theme(self):
        new = "light" if self.settings["theme"]=="dark" else "dark"
        self.settings["theme"] = new; save_settings(self.settings)
        ctk.set_appearance_mode(new)

    def _clear_background(self):
        self.settings["background"] = ""; save_settings(self.settings)
        if self.bg_label:
            self.bg_label.destroy(); self.bg_label=None; self.bg_frames=None

    # ---------------- Terms Popup ----------------
    def _show_terms(self):
        if self.terms_popup and self.terms_popup.winfo_exists(): return
        file = TERMS_FILES[self.LANG]; lines=[]
        if os.path.exists(file): lines=open(file,encoding="utf-8").read().splitlines()
        p = tk.Toplevel(self); self.terms_popup=p
        p.title(self.translate("📜 الشروط","📜 Terms & Rights")); p.geometry("400x300"); p.configure(bg="#333333")
        txt = tk.Text(p,bg="#333333",fg="#FFFFFF",font=("Segoe UI",12),wrap="word",bd=0,highlightthickness=0)
        txt.insert("1.0", "\n".join(lines)); txt.configure(state="disabled"); txt.pack(fill="both",expand=True,padx=10,pady=10)

    # ---------------- Account Management ----------------
    def load_accounts(self):
        for w in self.scroll_frame.winfo_children(): w.destroy()
        accounts=[]
        if LOGINUSERS_PATH and os.path.exists(LOGINUSERS_PATH):
            try:
                data=vdf.load(open(LOGINUSERS_PATH,encoding="utf-8"))
                for sid,info in data.get("users",{}).items():
                    ts=int(info.get("Timestamp",0))
                    last=datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")
                    accounts.append({
                        "steamid":sid,"name":info.get("PersonaName","Unknown"),
                        "login":info.get("AccountName",""),"last":last,
                        "most":info.get("MostRecent","0")
                    })
            except: pass
        if not accounts:
            ctk.CTkLabel(self.scroll_frame,text=self.translate("لا توجد حسابات","No accounts")).pack(pady=20)
            return
        running=is_steam_running()
        for acc in accounts: self._create_card(acc,running)

    def _create_card(self, acc, running):
        card=ctk.CTkFrame(self.scroll_frame,fg_color="#000000")
        card.pack(fill="x",pady=8,padx=10)
        img=self._get_avatar(acc["steamid"]); ph=ImageTk.PhotoImage(img)
        lbl=tk.Label(card,image=ph,bg="#000000"); lbl.image=ph; lbl.pack(side="left",padx=10,pady=10)
        info=(f"👤 {acc['name']}\n🆔 {acc['login']}\n"
              f"🕓 {self.translate('آخر دخول:','Last Login:')} {acc['last']}")
        ctk.CTkLabel(card,text=info,font=("Segoe UI",14),justify="left",text_color="#F4F4F4")\
            .pack(side="left",padx=10)
        if not running:
            text,fg,state="🔄 "+self.translate("تبديل","Switch"),"#4D5376","normal"
        else:
            if acc["most"]=="1":
                text,fg,state=self.translate("✅ مسجل","✅ Logged In"),"#24411D","disabled"
            else:
                text,fg,state="🔄 "+self.translate("تبديل","🔄 Switch"),"#4D5376","normal"
        ctk.CTkButton(card,text=text,fg_color=fg,state=state,width=140,
                      command=lambda a=acc:self._switch(a)).pack(side="right",padx=10,pady=10)

    def _get_avatar(self, steamid):
        path=os.path.join(AVATAR_DIR,f"{steamid}.jpg")
        if os.path.exists(path):
            try: return Image.open(path).resize((60,60))
            except: pass
        try:
            r=requests.get(f"https://steamcommunity.com/profiles/{steamid}/?xml=1",timeout=5)
            soup=BeautifulSoup(r.text,"xml"); url=soup.find("avatarMedium").text
            data=requests.get(url).content
            img=Image.open(BytesIO(data)).resize((60,60)); img.save(path); return img
        except:
            return Image.new("RGB",(60,60),color="#080505")

    def _switch(self, acc):
        if LOGINUSERS_PATH and os.path.exists(LOGINUSERS_PATH):
            shutil.copyfile(LOGINUSERS_PATH, LOGINUSERS_PATH+".bak")
            data=vdf.load(open(LOGINUSERS_PATH,encoding="utf-8"))
            for uid in data["users"]:
                data["users"][uid]["MostRecent"] = "1" if uid==acc["steamid"] else "0"
            vdf.dump(data, open(LOGINUSERS_PATH,"w",encoding="utf-8"), pretty=True)
            subprocess.call(["taskkill","/F","/IM","steam.exe"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            subprocess.Popen([STEAM_PATH,"-login", acc["login"]])
            self.load_accounts()
        else:
            messagebox.showwarning(self.translate("تنبيه","Warning"), self.translate("Steam not found",""))

    # ---------------- Background & Window ----------------
    def _load_background(self, w, h):
        bg=self.settings.get("background","")
        if not bg or not os.path.exists(bg): return
        try:
            img=Image.open(bg)
            if getattr(img,"is_animated",False) and self.settings.get("animated_background",True):
                self.bg_frames=[ImageTk.PhotoImage(f.resize((w,h))) for f in ImageSequence.Iterator(img)]
                if not self.bg_label:
                    self.bg_label=tk.Label(self); self.bg_label.place(x=0,y=0,relwidth=1,relheight=1); self.bg_label.lower()
                self._animate()
            else:
                f0=next(ImageSequence.Iterator(img)) if getattr(img,"is_animated",False) else img
                ph=ImageTk.PhotoImage(f0.resize((w,h)))
                if self.bg_label: self.bg_label.configure(image=ph)
                else:
                    self.bg_label=tk.Label(self,image=ph); self.bg_label.photo=ph
                    self.bg_label.place(x=0,y=0,relwidth=1,relheight=1); self.bg_label.lower()
        except: pass

    def _animate(self):
        self.bg_label.configure(image=self.bg_frames[self.bg_index])
        self.bg_index=(self.bg_index+1)%len(self.bg_frames)
        self.after(100, self._animate)

    def _on_resize(self, e):
        if e.widget==self and not getattr(self,"_resizing",False):
            self._resizing=True
            self.after(300, lambda: (self._load_background(e.width,e.height), setattr(self,"_resizing",False)))

    def _on_close(self):
        self.settings["window"]={
            "width":self.winfo_width(),"height":self.winfo_height(),
            "x":self.winfo_x(),"y":self.winfo_y()
        }
        save_settings(self.settings)
        self.destroy()

    def _on_drop(self, e):
        p=e.data.strip("{}")
        if os.path.exists(p):
            self.settings["background"]=p; save_settings(self.settings)
            self._load_background(self.winfo_width(),self.winfo_height())

# --------------------------------------------------------------------------------------------------
# Entry Point
# --------------------------------------------------------------------------------------------------
if __name__ == "__main__":
    # 1. تحقق من التحديث أولًا
    check_and_update()
    # 2. إذا ما كان فيه تحديث جديد (أو بعد انتهاء التحديث تلقائيًا)، عرض الـ splash أو التطبيق
    settings = load_settings()
    if not show_ascii_splash(settings):
        SteamSwitcherApp().mainloop()