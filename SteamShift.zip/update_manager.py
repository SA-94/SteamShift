import os
import sys
import requests
import zipfile
import subprocess
import customtkinter as ctk
from threading import Thread

# ─── Configuration ────────────────────────────────────────────────────────────
BASE_DIR            = os.path.dirname(os.path.abspath(sys.argv[0]))
VERSION_FILE        = os.path.join(BASE_DIR, "version.txt")
REMOTE_VERSION_URL  = "https://raw.githubusercontent.com/SA-94/SteamShift/main/version.txt"
REMOTE_PACKAGE_URL  = "https://raw.githubusercontent.com/SA-94/SteamShift/main/SteamShift.zip"
ICON_PATH           = os.path.join(BASE_DIR, "app.ico")

# ─── Appearance ───────────────────────────────────────────────────────────────
ctk.set_appearance_mode("System")
ctk.set_default_color_theme("dark-blue")

# ─── Helpers ─────────────────────────────────────────────────────────────────
def get_local_version():
    try:
        return open(VERSION_FILE, "r", encoding="utf-8").read().strip()
    except:
        return "0.0.0"

def get_remote_version():
    try:
        r = requests.get(REMOTE_VERSION_URL, timeout=5)
        r.raise_for_status()
        return r.text.strip()
    except:
        return None

def center_window(win, width, height):
    sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
    x = (sw - width) // 2
    y = (sh - height) // 2
    win.geometry(f"{width}x{height}+{x}+{y}")

# ─── Update Prompt ────────────────────────────────────────────────────────────
def prompt_update(remote, local):
    # نؤسّس root خفي
    root = ctk.CTk()
    root.withdraw()

    dlg = ctk.CTkToplevel(root)
    dlg.title("Update Available")
    dlg.resizable(False, False)
    if os.path.exists(ICON_PATH):
        dlg.iconbitmap(ICON_PATH)
    center_window(dlg, 480, 260)

    ctk.CTkLabel(
        dlg,
        text=f"A new version is available!\n\nCurrent: {local}\nNew: {remote}",
        font=ctk.CTkFont(size=16, weight="bold"),
        justify="center"
    ).pack(padx=20, pady=(30,10))

    btn_frame = ctk.CTkFrame(dlg, fg_color="transparent")
    btn_frame.pack(pady=20)
    ctk.CTkButton(
        btn_frame, text="Update Now", width=140,
        command=lambda: (dlg.destroy(), root.destroy())
    ).grid(row=0, column=0, padx=10)
    ctk.CTkButton(
        btn_frame, text="Remind Me Later", width=140, fg_color="#44475a",
        command=lambda: sys.exit(0)
    ).grid(row=0, column=1, padx=10)

    dlg.mainloop()

# ─── Download & Install Progress ───────────────────────────────────────────────
def show_progress_and_update():
    root = ctk.CTk()
    root.withdraw()

    win = ctk.CTkToplevel(root)
    win.title("Updating…")
    win.resizable(False, False)
    if os.path.exists(ICON_PATH):
        win.iconbitmap(ICON_PATH)
    center_window(win, 500, 150)

    ctk.CTkLabel(
        win,
        text="Downloading and installing update, please wait…",
        font=ctk.CTkFont(size=14),
        justify="center"
    ).pack(padx=20, pady=(20,10))

    progress = ctk.CTkProgressBar(win, width=460)
    progress.set(0)
    progress.pack(pady=(0,20))

    def download_worker():
        zip_path = os.path.join(BASE_DIR, "update.zip")
        success = False
        try:
            r = requests.get(REMOTE_PACKAGE_URL, stream=True, timeout=10)
            total = int(r.headers.get("content-length", 0))
            downloaded = 0
            with open(zip_path, "wb") as f:
                for chunk in r.iter_content(8192):
                    if not chunk: continue
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        progress.set(downloaded / total)
            if zipfile.is_zipfile(zip_path):
                with zipfile.ZipFile(zip_path, 'r') as z:
                    z.extractall(BASE_DIR)
                os.remove(zip_path)
                success = True
        except:
            pass
        finally:
            win.destroy()
            root.destroy()

        if not success:
            show_error()
            sys.exit(1)
        show_success_and_restart()

    Thread(target=download_worker, daemon=True).start()
    win.mainloop()

# ─── Success & Restart ───────────────────────────────────────────────────────
def show_success_and_restart():
    root = ctk.CTk()
    root.withdraw()

    dlg = ctk.CTkToplevel(root)
    dlg.title("Update Complete")
    dlg.resizable(False, False)
    if os.path.exists(ICON_PATH):
        dlg.iconbitmap(ICON_PATH)
    center_window(dlg, 400, 140)

    ctk.CTkLabel(
        dlg,
        text="Update installed successfully!\nRestarting now…",
        font=ctk.CTkFont(size=14, weight="bold"),
        justify="center"
    ).pack(expand=True, pady=20)

    def restart():
        python = sys.executable
        subprocess.Popen([python, os.path.join(BASE_DIR, "SteamShift.py")])
        sys.exit(0)

    dlg.after(2000, restart)
    dlg.mainloop()

# ─── Error Dialog ────────────────────────────────────────────────────────────
def show_error():
    root = ctk.CTk()
    root.withdraw()

    dlg = ctk.CTkToplevel(root)
    dlg.title("Update Failed")
    dlg.resizable(False, False)
    if os.path.exists(ICON_PATH):
        dlg.iconbitmap(ICON_PATH)
    center_window(dlg, 400, 140)

    ctk.CTkLabel(
        dlg,
        text="An error occurred during update.\nPlease try again later.",
        font=ctk.CTkFont(size=14),
        justify="center"
    ).pack(expand=True, pady=20)

    ctk.CTkButton(dlg, text="Exit", command=lambda: sys.exit(1)).pack(pady=(0,20))
    dlg.mainloop()

# ─── Main Check ───────────────────────────────────────────────────────────────
def check_and_update():
    local  = get_local_version()
    remote = get_remote_version()
    if not remote or remote == local:
        return True
    prompt_update(remote, local)
    show_progress_and_update()
    return False

if __name__ == "__main__":
    if not check_and_update():
        sys.exit(0)
