import os
import sys
import requests
import json
import hashlib
import subprocess
import customtkinter as ctk
import time
from threading import Thread
from pathlib import Path

# ─── Configuration ────────────────────────────────────────────────────────────
BASE_DIR               = os.path.dirname(os.path.abspath(sys.argv[0]))
DATA_DIR               = Path(os.getenv("LOCALAPPDATA") or os.path.expanduser("~/.local/share")) / "SteamShift"
DATA_DIR.mkdir(parents=True, exist_ok=True)

LOCAL_VERSION_FILE     = str(DATA_DIR / "version.txt")
REMOTE_MANIFEST_URL    = "https://raw.githubusercontent.com/SA-94/SteamShift/main/updates.json"
ICON_PATH              = os.path.join(BASE_DIR, "app.ico")

# ─── Appearance ───────────────────────────────────────────────────────────────
ctk.set_appearance_mode("System")
ctk.set_default_color_theme("dark-blue")

# ─── Helpers ─────────────────────────────────────────────────────────────────
def resource_path(relative_path):
    """
    لتحميل الملف المضمّن داخل الـ exe أو في التطوير
    """
    if hasattr(sys, '_MEIPASS'):
        base = sys._MEIPASS
    else:
        base = os.path.abspath(os.path.dirname(__file__))
    return os.path.join(base, relative_path)

def init_local_version():
    """
    عند أول تشغيل ينقل الرقم المضمّن إلى ملف DATA_DIR/version.txt
    """
    if not os.path.exists(LOCAL_VERSION_FILE):
        try:
            emb = open(resource_path("version.txt"), "r", encoding="utf-8").read().strip()
            with open(LOCAL_VERSION_FILE, "w", encoding="utf-8") as f:
                f.write(emb)
        except:
            pass

def get_local_version():
    try:
        return open(LOCAL_VERSION_FILE, "r", encoding="utf-8").read().strip()
    except:
        return "0.0.0"

def fetch_with_retry(url, timeout=5, retries=3, backoff=1):
    """
    جلب المحتوى من URL مع إعادة المحاولة.
    """
    attempt = 0
    while attempt < retries:
        try:
            r = requests.get(url, timeout=timeout)
            r.raise_for_status()
            return r
        except:
            attempt += 1
            if attempt >= retries:
                return None
            time.sleep(backoff)
            backoff *= 2

def fetch_remote_manifest():
    """
    تحميل ملف التحديث (updates.json) مع retry.
    """
    r = fetch_with_retry(REMOTE_MANIFEST_URL)
    if not r:
        return None
    try:
        return r.json()
    except:
        return None

def sha256_of_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            h.update(chunk)
    return h.hexdigest()

def center_window(win, width, height):
    sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
    x = (sw - width) // 2
    y = (sh - height) // 2
    win.geometry(f"{width}x{height}+{x}+{y}")

# ─── Update Prompt ────────────────────────────────────────────────────────────
def prompt_update(remote_version, local_version):
    root = ctk.CTk()
    root.withdraw()

    dlg = ctk.CTkToplevel(root)
    dlg.title("Update Available")
    dlg.resizable(False, False)
    if os.path.exists(ICON_PATH):
        dlg.iconbitmap(ICON_PATH)
    center_window(dlg, 480, 260)

    ctk.CTkLabel(
        dlg,
        text=f"A new release is available!\n\nCurrent: {local_version}\nNew: {remote_version}",
        font=ctk.CTkFont(size=16, weight="bold"),
        justify="center"
    ).pack(padx=20, pady=(30,10))

    btn_frame = ctk.CTkFrame(dlg, fg_color="transparent")
    btn_frame.pack(pady=20)
    ctk.CTkButton(
        btn_frame, text="Update Now", width=140,
        command=lambda: (dlg.destroy(), root.destroy())
    ).grid(row=0, column=0, padx=10)
    ctk.CTkButton(
        btn_frame, text="Remind Me Later", width=140, fg_color="#44475a",
        command=lambda: sys.exit(0)
    ).grid(row=0, column=1, padx=10)

    dlg.mainloop()

# ─── Download & Install Progress ───────────────────────────────────────────────
def show_progress_and_update(manifest):
    root = ctk.CTk()
    root.withdraw()

    win = ctk.CTkToplevel(root)
    win.title("Updating…")
    win.resizable(False, False)
    if os.path.exists(ICON_PATH):
        win.iconbitmap(ICON_PATH)
    center_window(win, 500, 150)

    ctk.CTkLabel(
        win,
        text="Downloading and installing update, please wait…",
        font=ctk.CTkFont(size=14),
        justify="center"
    ).pack(padx=20, pady=(20,10))

    progress = ctk.CTkProgressBar(win, width=460)
    progress.set(0)
    progress.pack(pady=(0,20))

    files = manifest.get("files", [])
    total_files = len(files)

    def worker():
        # حذف الملفات القديمة
        keep = {os.path.basename(__file__), os.path.basename(LOCAL_VERSION_FILE), "app.ico", "app.bmp", "license.txt"}
        for fname in os.listdir(BASE_DIR):
            if fname not in keep and not any(f["path"] == fname for f in files):
                try:
                    p = os.path.join(BASE_DIR, fname)
                    if os.path.isfile(p): os.remove(p)
                    elif os.path.isdir(p): import shutil; shutil.rmtree(p)
                except:
                    pass

        # تحميل وتحقق
        success = True
        for idx, info in enumerate(files, 1):
            url      = info["url"]
            target   = os.path.join(BASE_DIR, info["path"])
            exp_hash = info.get("sha256", "")
            r = fetch_with_retry(url)
            if not r:
                success = False; break
            try:
                with open(target, "wb") as f:
                    for chunk in r.iter_content(8192):
                        if chunk: f.write(chunk)
                if exp_hash and sha256_of_file(target).lower() != exp_hash.lower():
                    success = False; break
            except:
                success = False; break
            progress.set(idx/total_files)

        win.destroy(); root.destroy()

        if not success:
            show_error(); sys.exit(1)

        try:
            with open(LOCAL_VERSION_FILE, "w", encoding="utf-8") as vf:
                vf.write(manifest.get("version",""))
        except:
            pass

        show_success_and_restart()

    Thread(target=worker, daemon=True).start()
    win.mainloop()

# ─── Success & Restart ───────────────────────────────────────────────────────
def show_success_and_restart():
    root = ctk.CTk()
    root.withdraw()

    dlg = ctk.CTkToplevel(root)
    dlg.title("Update Complete")
    dlg.resizable(False, False)
    if os.path.exists(ICON_PATH):
        dlg.iconbitmap(ICON_PATH)
    center_window(dlg, 400, 140)

    ctk.CTkLabel(
        dlg,
        text="Update installed successfully!\nRestarting now…",
        font=ctk.CTkFont(size=14, weight="bold"),
        justify="center"
    ).pack(expand=True, pady=20)

    def restart():
        exe = os.path.join(BASE_DIR, "SteamShift.exe")
        if os.path.exists(exe):
            subprocess.Popen([exe])
        else:
            subprocess.Popen([sys.executable, os.path.join(BASE_DIR, "SteamShift.py")])
        sys.exit(0)

    dlg.after(2000, restart)
    dlg.mainloop()

# ─── Error Dialog ────────────────────────────────────────────────────────────
def show_error():
    root = ctk.CTk()
    root.withdraw()

    dlg = ctk.CTkToplevel(root)
    dlg.title("Update Failed")
    dlg.resizable(False, False)
    if os.path.exists(ICON_PATH):
        dlg.iconbitmap(ICON_PATH)
    center_window(dlg, 400, 140)

    ctk.CTkLabel(
        dlg,
        text="An error occurred during update.\nPlease try again later.",
        font=ctk.CTkFont(size=14),
        justify="center"
    ).pack(expand=True, pady=20)

    ctk.CTkButton(dlg, text="Exit", command=lambda: sys.exit(1)).pack(pady=(0,20))
    dlg.mainloop()

# ─── Main Check ───────────────────────────────────────────────────────────────
def check_and_update():
    init_local_version()
    local_version  = get_local_version()
    manifest      = fetch_remote_manifest()
    if not manifest or manifest.get("version","") == local_version:
        return True
    prompt_update(manifest["version"], local_version)
    show_progress_and_update(manifest)
    return False

if __name__ == "__main__":
    if not check_and_update():
        sys.exit(0)
