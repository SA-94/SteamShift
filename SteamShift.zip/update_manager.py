import os
import sys
import requests
import zipfile
import subprocess
import tkinter
from tkinter import messagebox

BASE_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))

# روابط الملفات على GitHub
REMOTE_VERSION_URL = "https://raw.githubusercontent.com/SA-94/SteamShift/main/version.txt"
REMOTE_PACKAGE_URL = "https://raw.githubusercontent.com/SA-94/SteamShift/main/SteamShift.zip"

def get_local_version():
    try:
        version = open(os.path.join(BASE_DIR, "version.txt")).read().strip()
        print(f"📝 الإصدار المحلي: {version}")
        return version
    except:
        print("❌ فشل في قراءة الإصدار المحلي.")
        return "0.0.0"

def get_remote_version():
    try:
        r = requests.get(REMOTE_VERSION_URL, timeout=5)
        print(f"🛰️ رد GitHub (version.txt): {r.status_code} - {r.text.strip()}")
        if r.status_code == 200:
            return r.text.strip()
        else:
            return None
    except Exception as e:
        print(f"❌ خطأ أثناء التحقق من الإصدار البعيد: {e}")
        return None

def ask_for_update():
    root = tkinter.Tk()
    root.withdraw()
    result = messagebox.askyesno("تحديث متاح", "يتوفر إصدار جديد من البرنامج.\nهل ترغب في التحديث الآن؟")
    root.destroy()
    return result

def download_update():
    print(f"🔗 رابط التحديث: {REMOTE_PACKAGE_URL}")
    r = requests.get(REMOTE_PACKAGE_URL, stream=True)
    print(f"🔍 حالة الاتصال: {r.status_code}")
    
    if r.status_code != 200:
        print("❌ لم يتم العثور على ملف التحديث (SteamShift.zip).")
        return None

    path = os.path.join(BASE_DIR, "update.zip")
    with open(path, "wb") as f:
        for chunk in r.iter_content(1024):
            f.write(chunk)
    return path

def apply_update(zip_path):
    if not zipfile.is_zipfile(zip_path):
        print("🚫 الملف المحمل ليس ملف ZIP صالح.")
        os.remove(zip_path)
        return False

    with zipfile.ZipFile(zip_path, 'r') as z:
        z.extractall(BASE_DIR)
    os.remove(zip_path)
    print("✅ تم التحديث بنجاح. إعادة التشغيل...")
    return True

def check_and_update():
    local = get_local_version()
    remote = get_remote_version()
    
    if not remote:
        print("⚠️ لا يمكن التحقق من الإصدار البعيد الآن. سيتم تشغيل البرنامج الحالي.")
        return True

    if remote != local:
        print(f"[!] إصدار جديد متاح: {remote} (الحالي: {local})")
        if ask_for_update():
            zip_path = download_update()
            if zip_path and apply_update(zip_path):
                python = sys.executable
                subprocess.Popen([python, os.path.join(BASE_DIR, "SteamShift.py")])
                sys.exit()
            else:
                print("❌ فشل التحديث.")
                return False
        else:
            print("🚪 المستخدم رفض التحديث. سيتم الإغلاق.")
            sys.exit()

    return True
