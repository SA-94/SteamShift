import os
import sys
import requests
import zipfile
import io
import customtkinter as ctk
import time
import subprocess
from pathlib import Path
from threading import Thread

# ─── Configuration ────────────────────────────────────────────────────────────
# Use DATA subfolder within application base directory for storing settings and version
BASE_DIR           = Path(os.path.dirname(os.path.abspath(sys.argv[0])))
DATA_DIR           = BASE_DIR / "DATA"
DATA_DIR.mkdir(parents=True, exist_ok=True)

LOCAL_VERSION_FILE = DATA_DIR / "version.txt"
REMOTE_VERSION_URL = "https://raw.githubusercontent.com/SA-94/SteamShift/main/version.txt"
REMOTE_ZIP_URL     = "https://github.com/SA-94/SteamShift/releases/latest/download/SteamShift.zip"
ICON_PATH          = os.path.join(BASE_DIR, "app.ico")

# ─── Appearance ───────────────────────────────────────────────────────────────
ctk.set_appearance_mode("System")
ctk.set_default_color_theme("dark-blue")

# ─── Helpers ─────────────────────────────────────────────────────────────────
def init_local_version():
    if not LOCAL_VERSION_FILE.exists():
        try:
            # copy embedded version.txt when bundled with PyInstaller
            base = getattr(sys, '_MEIPASS', BASE_DIR)
            src = os.path.join(base, "version.txt")
            if os.path.exists(src):
                LOCAL_VERSION_FILE.write_text(open(src, 'r', encoding='utf-8').read(), encoding='utf-8')
        except Exception:
            LOCAL_VERSION_FILE.write_text("0.0.0", encoding='utf-8')


def get_local_version():
    try:
        return LOCAL_VERSION_FILE.read_text(encoding='utf-8').strip()
    except Exception:
        return "0.0.0"


def fetch_text(url, timeout=5, retries=3, backoff=1):
    attempt = 0
    while attempt < retries:
        try:
            r = requests.get(url, timeout=timeout)
            r.raise_for_status()
            return r.text.strip()
        except Exception:
            attempt += 1
            time.sleep(backoff)
            backoff *= 2
    return None


def center_window(win, width, height):
    sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
    x = (sw - width) // 2
    y = (sh - height) // 2
    win.geometry(f"{width}x{height}+{x}+{y}")

# ─── Update Prompt ────────────────────────────────────────────────────────────
def prompt_update(remote_version, local_version):
    root = ctk.CTk()
    root.withdraw()

    dlg = ctk.CTkToplevel(root)
    dlg.title("Update Available")
    dlg.resizable(False, False)
    if os.path.exists(ICON_PATH):
        dlg.iconbitmap(ICON_PATH)
    center_window(dlg, 480, 260)

    ctk.CTkLabel(
        dlg,
        text=f"A new release is available!\n\nCurrent: {local_version}\nNew: {remote_version}",
        font=ctk.CTkFont(size=16, weight="bold"),
        justify="center"
    ).pack(padx=20, pady=(30,10))

    btn_frame = ctk.CTkFrame(dlg, fg_color="transparent")
    btn_frame.pack(pady=20)
    ctk.CTkButton(
        btn_frame, text="Update Now", width=140,
        command=lambda: (dlg.destroy(), root.destroy())
    ).grid(row=0, column=0, padx=10)
    ctk.CTkButton(
        btn_frame, text="Remind Me Later", width=140, fg_color="#44475a",
        command=lambda: sys.exit(0)
    ).grid(row=0, column=1, padx=10)

    dlg.mainloop()

# ─── Download & Install ───────────────────────────────────────────────────────
def show_progress_and_update(remote_version):
    root = ctk.CTk()
    root.withdraw()

    win = ctk.CTkToplevel(root)
    win.title("Updating…")
    win.resizable(False, False)
    if os.path.exists(ICON_PATH):
        win.iconbitmap(ICON_PATH)
    center_window(win, 500, 150)

    ctk.CTkLabel(
        win,
        text="Downloading and installing update, please wait…",
        font=ctk.CTkFont(size=14),
        justify="center"
    ).pack(padx=20, pady=(20,10))

    progress = ctk.CTkProgressBar(win, width=460)
    progress.set(0)
    progress.pack(pady=(0,20))

    def worker():
        try:
            r = requests.get(REMOTE_ZIP_URL, stream=True)
            r.raise_for_status()
            total = int(r.headers.get('content-length', 0))
            zip_io = io.BytesIO()
            downloaded = 0
            for chunk in r.iter_content(8192):
                if chunk:
                    zip_io.write(chunk)
                    downloaded += len(chunk)
                    progress.set(downloaded / total)

            zip_io.seek(0)
            with zipfile.ZipFile(zip_io) as z:
                z.extractall(BASE_DIR)

            # update local version file
            LOCAL_VERSION_FILE.write_text(remote_version, encoding='utf-8')
        except Exception:
            win.destroy(); root.destroy(); show_error(); sys.exit(1)

        win.destroy(); root.destroy(); show_success_and_restart()

    Thread(target=worker, daemon=True).start()
    win.mainloop()

# ─── Success & Restart ────────────────────────────────────────────────────────
def show_success_and_restart():
    root = ctk.CTk()
    root.withdraw()

    dlg = ctk.CTkToplevel(root)
    dlg.title("Update Complete")
    dlg.resizable(False, False)
    if os.path.exists(ICON_PATH):
        dlg.iconbitmap(ICON_PATH)
    center_window(dlg, 400, 140)

    ctk.CTkLabel(
        dlg,
        text="Update installed successfully!\nRestarting now…",
        font=ctk.CTkFont(size=14, weight="bold"),
        justify="center"
    ).pack(expand=True, pady=20)

    def restart():
        exe = os.path.join(BASE_DIR, "SteamShift.exe")
        if os.path.exists(exe):
            os.startfile(exe)
        else:
            subprocess.Popen([sys.executable, os.path.join(BASE_DIR, "SteamShift.py")])
        sys.exit(0)

    dlg.after(2000, restart)
    dlg.mainloop()

# ─── Error Dialog ────────────────────────────────────────────────────────────
def show_error():
    root = ctk.CTk()
    root.withdraw()

    dlg = ctk.CTkToplevel(root)
    dlg.title("Update Failed")
    dlg.resizable(False, False)
    if os.path.exists(ICON_PATH):
        dlg.iconbitmap(ICON_PATH)
    center_window(dlg, 400, 140)

    ctk.CTkLabel(
        dlg,
        text="An error occurred during update.\nPlease try again later.",
        font=ctk.CTkFont(size=14),
        justify="center"
    ).pack(expand=True, pady=20)

    ctk.CTkButton(dlg, text="Exit", command=lambda: sys.exit(1)).pack(pady=(0,20))
    dlg.mainloop()

# ─── Main Check ───────────────────────────────────────────────────────────────
def check_and_update():
    init_local_version()
    local_version  = get_local_version()
    remote_version = fetch_text(REMOTE_VERSION_URL)
    if not remote_version or remote_version == local_version:
        return True
    prompt_update(remote_version, local_version)
    show_progress_and_update(remote_version)
    return False

if __name__ == "__main__":
    if not check_and_update():
        sys.exit(0)
