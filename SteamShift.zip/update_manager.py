import os
import sys
import requests
import zipfile
import subprocess
import customtkinter as ctk
from threading import Thread

# إعدادات
BASE_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
REMOTE_VERSION_URL = "https://raw.githubusercontent.com/SA-94/SteamShift/main/version.txt"
REMOTE_PACKAGE_URL = "https://raw.githubusercontent.com/SA-94/SteamShift/main/SteamShift.zip"
ICON_PATH = os.path.join(BASE_DIR, "app.ico")

# إعداد المظهر
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")


# --------------------------------------------
# الأدوات المساعدة
# --------------------------------------------
def get_local_version():
    try:
        with open(os.path.join(BASE_DIR, "version.txt"), "r") as f:
            return f.read().strip()
    except:
        return "0.0.0"


def get_remote_version():
    try:
        r = requests.get(REMOTE_VERSION_URL, timeout=5)
        if r.status_code == 200:
            return r.text.strip()
    except:
        return None


# --------------------------------------------
# واجهة التأكيد قبل التحديث
# --------------------------------------------
def ask_for_update_gui(remote, local):
    dlg = ctk.CTk()
    dlg.title("🔄 تحديث متاح")
    dlg.geometry("480x260")
    dlg.resizable(False, False)
    if os.path.exists(ICON_PATH):
        dlg.iconbitmap(ICON_PATH)

    sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
    dlg.geometry(f"+{(sw - 480) // 2}+{(sh - 260) // 2}")

    ctk.CTkLabel(
        dlg,
        text=f"🚀 إصدار جديد متاح!\n\nالإصدار الحالي: {local}\nالإصدار الجديد: {remote}",
        font=ctk.CTkFont(size=16, weight="bold"),
        justify="center"
    ).pack(pady=(30, 10), padx=20)

    btn_frame = ctk.CTkFrame(dlg, fg_color="transparent")
    btn_frame.pack(pady=10)

    ctk.CTkButton(
        btn_frame, text="نعم، حدّث الآن", width=120, command=dlg.destroy
    ).grid(row=0, column=0, padx=10)

    ctk.CTkButton(
        btn_frame, text="لاحقًا", width=120, fg_color="#44475a", command=lambda: sys.exit()
    ).grid(row=0, column=1, padx=10)

    dlg.mainloop()


# --------------------------------------------
# شريط التحديث والتنزيل
# --------------------------------------------
def show_download_progress():
    win = ctk.CTkToplevel()
    win.title("⏬ جاري التحديث...")
    win.geometry("500x160")
    win.resizable(False, False)
    if os.path.exists(ICON_PATH):
        win.iconbitmap(ICON_PATH)

    sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
    win.geometry(f"+{(sw - 500) // 2}+{(sh - 160) // 2}")

    ctk.CTkLabel(
        win, text="يرجى الانتظار أثناء تحميل التحديث وتثبيته...",
        font=ctk.CTkFont(size=14)
    ).pack(pady=(20, 10))

    bar = ctk.CTkProgressBar(win, width=440)
    bar.set(0)
    bar.pack(pady=(0, 20))

    def update_bar(pct):
        bar.set(pct / 100)

    def download_and_extract(zip_path, progress_callback):
        try:
            r = requests.get(REMOTE_PACKAGE_URL, stream=True, timeout=10)
            total = int(r.headers.get("content-length", 0))
            downloaded = 0

            with open(zip_path, "wb") as f:
                for chunk in r.iter_content(8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        progress_callback((downloaded / total) * 100)

            if zipfile.is_zipfile(zip_path):
                with zipfile.ZipFile(zip_path, 'r') as z:
                    z.extractall(BASE_DIR)
                os.remove(zip_path)
                return True
        except:
            pass
        if os.path.exists(zip_path):
            os.remove(zip_path)
        return False

    def worker():
        zip_path = os.path.join(BASE_DIR, "update.zip")
        success = download_and_extract(zip_path, update_bar)
        win.destroy()
        if success:
            show_success_message()
            subprocess.Popen([sys.executable, os.path.join(BASE_DIR, "SteamShift.py")])
            sys.exit()
        else:
            show_error_message()

    Thread(target=worker, daemon=True).start()
    win.mainloop()


# --------------------------------------------
# واجهة النجاح
# --------------------------------------------
def show_success_message():
    dlg = ctk.CTk()
    dlg.title("✅ تم التحديث")
    dlg.geometry("400x180")
    dlg.resizable(False, False)
    if os.path.exists(ICON_PATH):
        dlg.iconbitmap(ICON_PATH)

    sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
    dlg.geometry(f"+{(sw - 400) // 2}+{(sh - 180) // 2}")

    ctk.CTkLabel(
        dlg,
        text="🎉 تم تثبيت التحديث بنجاح!\nسيتم الآن إعادة تشغيل التطبيق.",
        font=ctk.CTkFont(size=16, weight="bold"),
        justify="center"
    ).pack(expand=True, pady=30)

    dlg.after(2000, dlg.destroy)
    dlg.mainloop()


# --------------------------------------------
# واجهة الخطأ
# --------------------------------------------
def show_error_message():
    dlg = ctk.CTk()
    dlg.title("❌ خطأ في التحديث")
    dlg.geometry("400x150")
    dlg.resizable(False, False)
    if os.path.exists(ICON_PATH):
        dlg.iconbitmap(ICON_PATH)

    sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
    dlg.geometry(f"+{(sw - 400) // 2}+{(sh - 150) // 2}")

    ctk.CTkLabel(
        dlg,
        text="حدث خطأ أثناء تنزيل أو تثبيت التحديث.\nيرجى المحاولة لاحقًا.",
        font=ctk.CTkFont(size=14),
        justify="center"
    ).pack(expand=True, pady=30)

    ctk.CTkButton(dlg, text="خروج", command=lambda: sys.exit()).pack(pady=5)
    dlg.mainloop()


# --------------------------------------------
# التحقق من وجود تحديث
# --------------------------------------------
def check_and_update():
    local = get_local_version()
    remote = get_remote_version()
    if not remote or remote == local:
        return True
    ask_for_update_gui(remote, local)
    show_download_progress()
    return False
