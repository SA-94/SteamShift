import os
import sys
import requests
import zipfile
import subprocess
import tkinter
from tkinter import messagebox

BASE_DIR = os.path.dirname(sys.argv[0])

# روابط المستودع
REMOTE_VERSION_URL = "https://raw.githubusercontent.com/USERNAME/REPO/main/version.txt"
REMOTE_PACKAGE_URL = "https://github.com/USERNAME/REPO/releases/latest/download/SteamShift.zip"

def get_local_version():
    try:
        return open(os.path.join(BASE_DIR, "version.txt")).read().strip()
    except:
        return "0.0.0"

def get_remote_version():
    r = requests.get(REMOTE_VERSION_URL, timeout=5)
    return r.text.strip()

def ask_for_update():
    root = tkinter.Tk()
    root.withdraw()  # إخفاء النافذة الرئيسية
    result = messagebox.askyesno("تحديث متاح", "يتوفر إصدار جديد من البرنامج.\nهل ترغب في التحديث الآن؟")
    root.destroy()
    return result

def download_update():
    r = requests.get(REMOTE_PACKAGE_URL, stream=True)
    path = os.path.join(BASE_DIR, "update.zip")
    with open(path, "wb") as f:
        for chunk in r.iter_content(1024):
            f.write(chunk)
    return path

def apply_update(zip_path):
    if not zipfile.is_zipfile(zip_path):
        print("🚫 الملف ليس zip صالح")
        os.remove(zip_path)
        return False

    with zipfile.ZipFile(zip_path, 'r') as z:
        z.extractall(BASE_DIR)
    os.remove(zip_path)
    return True

def check_and_update():
    local = get_local_version()
    try:
        remote = get_remote_version()
    except:
        print("⚠️ فشل في الاتصال بالمستودع.")
        return True  # نكمل على الإصدار القديم

    if remote != local:
        print(f"[!] إصدار جديد متاح: {remote} (الحالي: {local})")
        if ask_for_update():
            zip_path = download_update()
            if apply_update(zip_path):
                python = sys.executable
                subprocess.Popen([python, os.path.join(BASE_DIR, "SteamShift.py")])
                sys.exit()
            else:
                print("فشل التحديث.")
                return False
        else:
            print("🚪 المستخدم رفض التحديث. سيتم الإغلاق.")
            sys.exit()
    return True
